function BankLogo(){
	
	$(document).ready(()=>{
		$("#BankLogo").html(`
			<div class="mainLogo py-5">
				<div class="SubTitle text-center py-3">
					<h2>Our<b class="text-success">Banking Partners</b></h2>
					<p>Your Trusted and Assured Builders and Developers.</p>
				</div>
				<div class="container">
					<div class="BankingLogos d-flex" id="Tslides">
						<div class="B">
							<img src="img/11.png" alt="shree ganesh homes">
						</div>
						<div class="B">
							<img src="img/12.png" alt="shree ganesh homes">
						</div>
						<div class="B">
							<img src="img/13.png" alt="shree ganesh homes">
						</div>
						<div class="B">
							<img src="img/14.png" alt="shree ganesh homes">
						</div>
						<div class="B">
							<img src="img/15.png" alt="shree ganesh homes">
						</div>
						<div class="B">
							<img src="img/6.png" alt="shree ganesh homes">
						</div>
						<div class="B">
							<img src="img/7.png" alt="shree ganesh homes">
						</div>
						<div class="B">
							<img src="img/8.png" alt="shree ganesh homes">
						</div>
						<div class="B">
							<img src="img/9.png" alt="shree ganesh homes">
						</div>
						<div class="B">
							<img src="img/10.png" alt="shree ganesh homes">
						</div>
						
						
					 </div>
				</div>
			</div>
		`);	
	
		 $('.BankingLogos').slick({
		  infinite: true,
		  slidesToShow: 4,
		  slidesToScroll: 1,
		  autoplay: true,
		  autoplaySpeed: 2000,
		  arrows:true,
		  responsive: [
			{
			  breakpoint: 1024,
			  settings: {
				slidesToShow: 3,
				slidesToScroll: 3,
				infinite: true,
				dots: true
			  }
			},
			{
			  breakpoint: 600,
			  settings: {
				slidesToShow: 2,
				slidesToScroll: 2
			  }
			},
			{
			  breakpoint: 480,
			  settings: {
				slidesToShow: 1,
				slidesToScroll: 1
			  }
			}
		]
		});
	});

}

export default BankLogo;