
function SearchQuery(){
	$(document).ready(()=>{
		$("#formOption").html(`
			<div class="mainSearch">
				<div class="container">
					<div class="searchBox">
					
						<div class="Sbox1">
							<label>Location</label>
							<select name="Location" id="City">
							  <option value="Bilaspur">Bilaspur</option>
							  <option value="Raipur">Raipur</option>							  
							</select>
						</div><!--end--location-->
						
						<div class="Sbox1">
							<label>Location</label>
							<select name="Location" id="City">
							  <option value="Bilaspur">Bilaspur</option>
							  <option value="Raipur">Raipur</option>							  
							</select>
						</div><!--end--Service-->
						
						<div class="Sbox1">
							<label>Location</label>
							<select name="Location" id="City">
							  <option value="Bilaspur">Bilaspur</option>
							  <option value="Raipur">Raipur</option>							  
							</select>
						</div><!--end--location-->
						
						<div class="Sbox1">
							<label>Location</label>
							<select name="Location" id="City">
							  <option value="Bilaspur">Bilaspur</option>
							  <option value="Raipur">Raipur</option>							  
							</select>
						</div><!--end--location-->
						
					</div>
				</div>
			</div>
		`);
	});
}
export default SearchQuery;