let Data=[
	{
		id:"Header",
		HeadData:["+91-7000339054","shivaaru27@gmail.com"],
		Address:"Shanti Nagar, Bilaspur-Chhattisgarh, Chhattisgarh 495001",
		HeadCicon:["fa-solid fa-phone","fa-solid fa-envelope"],
		HeadSocial:["fa-brands fa-facebook","fa-brands fa-instagram","fa-brands fa-twitter","fa-brands fa-youtube"],
		
	},
	{
		id:"navigation",
		logo:"img/logo.png",
		alt:"Best Digital Board Solution",
		navData:["HOME","ABOUT","PROJECTS","GALLERY","VIDEOS","CONTACT"],
		navDataLink:["index.html","About.html","Services.html","Gallery.html","Videos.html","Contactus.html"],
		Services:["Akdanta Nivash","Shivay Homes","Ganesh Vihar","Shivay Nagar Fase 2"],
		Slink:["Akdunta.html","Shivayhomes.html","Ganeshvihar.html","Shivaynagar.html"]
		
	}
]                        

export default Data;