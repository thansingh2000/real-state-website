

// function YoutubeVedios(){
		// let Apikey = "AIzaSyBfJaR9g-rzL658X7GfoqgLfE5jtECfSos";
		// let url = "https://www.googleapis.com/youtube/v3/videos?";
		// let ApiUrl`https://youtube.googleapis.com/youtube/v3/videos?id=UC_x5XG1OV2P6uZZ5FSM9Ttw&maxResults=25&key=${Apikey}`

		// // fetch(url + new URLSearchParams({
			// // key: Apikey,
			// // part: 'snippet',
			// // chart: 'mostPopular',
			// // maxResults: 5,
			// // regionCode: 'IN',
			// // channelId: 'UC4JCksJF76g_MdzPVBJoC3Q'
		// // }))
		// fetch(ApiUrl)
		// .then((res)=>{
			// return res.json();
		// }).then((data)=>{
			// console.log(data);
		// });	
// }

// export default YoutubeVedios;

